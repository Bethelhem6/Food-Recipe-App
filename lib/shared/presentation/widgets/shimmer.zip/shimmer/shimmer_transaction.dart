import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class PlaceShimmerLoader extends StatelessWidget {
  const PlaceShimmerLoader({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: lodaing.map((e) => e).toList(),
    );
  }
}

List<Widget> lodaing = List.generate(10, (index) => const LoadingWidget());

class LoadingWidget extends StatelessWidget {
  const LoadingWidget({
    super.key,
  });

  Widget _shimmer(BuildContext context) {
    return Shimmer.fromColors(
        baseColor: Colors.grey[300]!,
        highlightColor: Colors.grey[100]!,
        child: Container(
          color: Colors.white,
        ));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.white,
          boxShadow: const [
            BoxShadow(
              color: Color.fromARGB(255, 246, 246, 246),
              blurRadius: 4.0, // soften the shadow
              spreadRadius: 1.0, //extend the shadow
              offset: Offset(
                1.0, // Move to right 5  horizontally
                1.0, // Move to bottom 5 Vertically
              ),
            ),
          ]),
      margin: EdgeInsets.symmetric(
          vertical: 10, horizontal: MediaQuery.of(context).size.width * .01),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row(
          //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //   children: [
          //     SizedBox(
          //       height: 10,
          //       width: MediaQuery.of(context).size.width * .6,
          //       child: _shimmer(context),
          //     ),
          //     SizedBox(
          //       height: 10,
          //       width: MediaQuery.of(context).size.width * .1,
          //       child: _shimmer(context),
          //     ),
          //   ],
          // ),
          SizedBox(
            height: 10,
            width: MediaQuery.of(context).size.width * .8,
            child: _shimmer(context),
          ),
          const SizedBox(
            height: 5,
          ),
          SizedBox(
            height: 6,
            width: MediaQuery.of(context).size.width * .6,
            child: _shimmer(context),
          ),
          const SizedBox(
            height: 5,
          ),
          SizedBox(
            height: 3,
            width: MediaQuery.of(context).size.width * .4,
            child: _shimmer(context),
          ),
        ],
      ),
    );
  }
}
