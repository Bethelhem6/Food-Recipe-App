import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class ProfileShimmer extends StatelessWidget {
  const ProfileShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(children: [
      const SizedBox(
        height: 30,
      ),
      SizedBox(
        height: 100,
        child: Stack(
          children: [
            Positioned(
              left: 0,
              bottom: 0,
              right: 0,
              top: 0,
              child: Container(
                margin: EdgeInsets.symmetric(
                    horizontal: MediaQuery.of(context).size.width * .38),
                child: CircleAvatar(
                  radius: 60,
                  child: Shimmer.fromColors(
                    baseColor: const Color.fromARGB(255, 206, 206, 206),
                    highlightColor: Colors.grey[100]!,
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(100)),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
      // CircleAvatar(
      //   radius: 30,

      //   child: Container(
      //       // width: 70,
      //       // height: 70,
      //       decoration: BoxDecoration(borderRadius: BorderRadius.circular(100)),
      //       margin: EdgeInsets.symmetric(
      //           horizontal: MediaQuery.of(context).size.width * .4),
      //       child: Shimmer.fromColors(
      //         baseColor: Color.fromARGB(255, 206, 206, 206)!,
      //         highlightColor: Colors.grey[100]!,
      //         child: Container(
      //           decoration: BoxDecoration(
      //               color: Colors.white,
      //               borderRadius: BorderRadius.circular(100)),
      //         ),
      //       )),
      // ),
      ...lodaing.map((e) => e),
    ]);
  }
}

List<Widget> lodaing = List.generate(10, (index) => const LoadingWidget());

class LoadingWidget extends StatelessWidget {
  const LoadingWidget({
    super.key,
  });

  Widget _shimmer(BuildContext context) {
    return Shimmer.fromColors(
        baseColor: Colors.grey[300]!,
        highlightColor: Colors.grey[100]!,
        child: Container(
          color: Colors.white,
        ));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      margin: EdgeInsets.symmetric(
          vertical: 5, horizontal: MediaQuery.of(context).size.width * .04),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 10,
            width: MediaQuery.of(context).size.width * .3,
            child: _shimmer(context),
          ),
          const SizedBox(
            height: 5,
          ),
          SizedBox(
            height: 45,
            // width: MediaQuery.of(context).size.width * .6,

            child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: _shimmer(context)),
          ),
        ],
      ),
    );
  }
}
